#!/bin/bash

pip install requests
pip install pyyaml

python3 check_password.py